export const ServicosHotel=["ginasio", "spa", "bar"]

export const ServicosQuartos=["arcondicionado", "frigobar", "tv"]

