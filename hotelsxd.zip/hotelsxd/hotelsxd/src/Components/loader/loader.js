import { Loader} from "rsuite"
import "./loader.css"
export const ScreenLoader = () => {


  return (
    <div>
        <Loader  content="loading..." center />
    </div>
  );
};
